import React from 'react';
import AddTask from '../components/AddTask';

const AddTaskPage = () => {
  return (
    <div>
      <AddTask />
    </div>
  );
};

export default AddTaskPage;
