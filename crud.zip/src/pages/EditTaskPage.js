import React from 'react';
import EditTask from '../components/EditTask';

const EditTaskPage = () => {
  return (
    <div>
      <EditTask />
    </div>
  );
};

export default EditTaskPage;
