import React from 'react';
import TaskList from '../components/TaskList';

const HomePage = () => {
  return (
    <div>
      <TaskList />
    </div>
  );
};

export default HomePage;
